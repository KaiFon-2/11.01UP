"""Инициализация базы данных.

  python init_db.py        — пересоздаёт БД library_db с нуля (схема + тестовые книги + пользователи)
  python init_db.py users  — только добавляет admin / user, если их ещё нет (данные не трогает)
  python init_db.py upgrade — добавляет таблицы reservations и reviews в уже созданную БД (данные не трогает)
"""
import os
import sys

import pymysql
from werkzeug.security import generate_password_hash

from config import BASE_DIR, Config

DEFAULT_USERS = [
    ('admin', 'admin@library.local', 'Администратор', 'admin123', 'admin'),
    ('user', 'user@library.local', 'Иван Читателев', 'user123', 'user'),
]


def run_script(cursor, path):
    with open(path, encoding='utf-8') as f:
        sql = f.read()
    for statement in sql.split(';'):
        if statement.strip():
            cursor.execute(statement)


def create_users(cursor):
    cursor.execute('USE ' + Config.DB_NAME)
    for username, email, full_name, password, role in DEFAULT_USERS:
        cursor.execute(
            'INSERT IGNORE INTO users (username, email, full_name, password_hash, role) '
            'VALUES (%s, %s, %s, %s, %s)',
            (username, email, full_name, generate_password_hash(password), role),
        )


def main():
    conn = pymysql.connect(
        host=Config.DB_HOST, port=Config.DB_PORT,
        user=Config.DB_USER, password=Config.DB_PASSWORD,
        charset='utf8mb4', autocommit=True,
    )
    with conn.cursor() as cur:
        args = sys.argv[1:]
        if 'upgrade' in args:
            run_script(cur, os.path.join(BASE_DIR, 'sql', 'upgrade_v2.sql'))
        elif 'users' not in args:
            run_script(cur, os.path.join(BASE_DIR, 'sql', 'schema.sql'))
            run_script(cur, os.path.join(BASE_DIR, 'sql', 'seed.sql'))
        create_users(cur)
    conn.close()
    print('Готово. Вход: admin / admin123  и  user / user123')


if __name__ == '__main__':
    main()
