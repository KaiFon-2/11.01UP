"""Интеграционные тесты. Работают с реальной БД library_db (нужен предварительно python init_db.py).
Все тестовые данные создаются с префиксом zz_test и удаляются после прогона.

Запуск:  python -m unittest discover -s tests -v
"""
import io
import os
import sys
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from db import execute, query  # noqa: E402

PREFIX = 'zz_test'


class AppTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.ctx = cls.app.app_context()
        cls.ctx.push()

    @classmethod
    def tearDownClass(cls):
        cls._cleanup()
        cls.ctx.pop()

    @classmethod
    def _cleanup(cls):
        for table in ('reviews', 'reservations'):
            execute(f"DELETE FROM {table} WHERE user_id IN (SELECT id FROM users WHERE username LIKE '{PREFIX}%')")
        execute(f"DELETE FROM fines WHERE user_id IN (SELECT id FROM users WHERE username LIKE '{PREFIX}%')")
        execute(f"DELETE FROM loans WHERE user_id IN (SELECT id FROM users WHERE username LIKE '{PREFIX}%')")
        execute(f"DELETE FROM books WHERE title LIKE '{PREFIX}%'")
        execute(f"DELETE FROM authors WHERE name LIKE '{PREFIX}%'")
        execute(f"DELETE FROM users WHERE username LIKE '{PREFIX}%'")

    def setUp(self):
        self._cleanup()
        self.client = self.app.test_client()

    # --- помощники ---
    def login(self, client, username, password):
        return client.post('/login', data={'username': username, 'password': password},
                           follow_redirects=True)

    def admin_client(self):
        c = self.app.test_client()
        self.login(c, 'admin', 'admin123')
        return c

    def register_and_login(self, name=PREFIX + '_reader'):
        c = self.app.test_client()
        r = c.post('/register', data={'username': name, 'full_name': 'Тест Тестов',
                                      'email': f'{name}@t.local', 'password': 'secret1',
                                      'password2': 'secret1'}, follow_redirects=True)
        self.assertIn('Регистрация успешна', r.get_data(as_text=True))
        self.login(c, name, 'secret1')
        return c, query('SELECT id FROM users WHERE username=%s', (name,), one=True)['id']

    def make_book(self, copies=2, title=PREFIX + ' book'):
        c = self.admin_client()
        c.post('/books/add', data={'title': title, 'author': PREFIX + ' author', 'genre_id': 1,
                                   'year': 2000, 'total_copies': copies, 'description': 'd'},
               follow_redirects=True)
        return query('SELECT * FROM books WHERE title=%s', (title,), one=True), c


class TestPublicPages(AppTestCase):
    def test_pages_open(self):
        for url in ('/', '/books/', '/books/?q=Толстой', '/books/?genre=3&available=1',
                    '/login', '/register'):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_search_finds_author(self):
        html = self.client.get('/books/?q=Достоевский').get_data(as_text=True)
        self.assertIn('Преступление и наказание', html)
        self.assertNotIn('Мастер и Маргарита', html)

    def test_book_detail_and_404(self):
        self.assertEqual(self.client.get('/books/1').status_code, 200)
        self.assertEqual(self.client.get('/books/999999').status_code, 404)


class TestAuthAndRoles(AppTestCase):
    def test_login_wrong_password(self):
        r = self.login(self.client, 'admin', 'wrong')
        self.assertIn('Неверный логин или пароль', r.get_data(as_text=True))

    def test_guest_redirected(self):
        for url in ('/loans/my', '/admin/', '/reports/', '/books/add'):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 302, url)
            self.assertIn('/login', r.headers['Location'])

    def test_user_forbidden_on_admin_pages(self):
        c, _ = self.register_and_login()
        for url in ('/admin/', '/admin/users', '/admin/fines', '/reports/', '/loans/all',
                    '/books/add', '/books/1/edit'):
            self.assertEqual(c.get(url).status_code, 403, url)
        self.assertEqual(c.post('/books/1/delete').status_code, 403)

    def test_admin_pages_open(self):
        c = self.admin_client()
        for url in ('/admin/', '/admin/users', '/admin/fines', '/reports/', '/loans/all',
                    '/loans/all?status=overdue', '/books/add', '/books/1/edit', '/loans/my'):
            self.assertEqual(c.get(url).status_code, 200, url)

    def test_duplicate_registration(self):
        self.register_and_login()
        r = self.app.test_client().post('/register', data={
            'username': PREFIX + '_reader', 'full_name': 'X', 'email': 'other@t.local',
            'password': 'secret1', 'password2': 'secret1'})
        self.assertIn('уже существует', r.get_data(as_text=True))

    def test_open_redirect_blocked(self):
        r = self.client.post('/login?next=//evil.com',
                             data={'username': 'user', 'password': 'user123'})
        self.assertNotIn('evil.com', r.headers['Location'])


class TestBooksCrud(AppTestCase):
    def test_create_edit_delete(self):
        book, c = self.make_book(copies=2)
        self.assertIsNotNone(book)
        self.assertEqual(book['available_copies'], 2)

        r = c.post(f'/books/{book["id"]}/edit', data={
            'title': PREFIX + ' book', 'author': PREFIX + ' author', 'genre_id': 2,
            'year': 2001, 'total_copies': 5}, follow_redirects=True)
        self.assertIn('Изменения сохранены', r.get_data(as_text=True))
        book = query('SELECT * FROM books WHERE id=%s', (book['id'],), one=True)
        self.assertEqual((book['total_copies'], book['available_copies'], book['genre_id']), (5, 5, 2))

        r = c.post(f'/books/{book["id"]}/delete', follow_redirects=True)
        self.assertIn('удалена', r.get_data(as_text=True))
        self.assertIsNone(query('SELECT id FROM books WHERE id=%s', (book['id'],), one=True))

    def test_validation(self):
        c = self.admin_client()
        r = c.post('/books/add', data={'title': '', 'author': '', 'genre_id': '', 'total_copies': 0})
        html = r.get_data(as_text=True)
        self.assertIn('Укажите название', html)
        self.assertIn('Укажите автора', html)

    def test_cover_upload(self):
        c = self.admin_client()
        png = (b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00'
               b'\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xf8\xff\xff?\x00\x05\xfe\x02\xfe\xa7'
               b'5\x81\x84\x00\x00\x00\x00IEND\xaeB`\x82')
        c.post('/books/add', data={'title': PREFIX + ' cover', 'author': PREFIX + ' author',
                                   'genre_id': 1, 'total_copies': 1,
                                   'cover': (io.BytesIO(png), 'c.png')},
               content_type='multipart/form-data')
        book = query('SELECT * FROM books WHERE title=%s', (PREFIX + ' cover',), one=True)
        self.assertTrue(book['cover'])
        path = os.path.join(self.app.config['UPLOAD_FOLDER'], book['cover'])
        self.assertTrue(os.path.exists(path))
        c.post(f'/books/{book["id"]}/delete')
        self.assertFalse(os.path.exists(path))


class TestLoans(AppTestCase):
    def book_state(self, book_id):
        return query('SELECT available_copies FROM books WHERE id=%s', (book_id,), one=True)['available_copies']

    def test_issue_and_return(self):
        book, _ = self.make_book(copies=2)
        c, uid = self.register_and_login()
        r = c.post(f'/loans/issue/{book["id"]}', follow_redirects=True)
        self.assertIn('Книга выдана', r.get_data(as_text=True))
        self.assertEqual(self.book_state(book['id']), 1)

        loan = query('SELECT * FROM loans WHERE user_id=%s', (uid,), one=True)
        self.assertEqual(loan['due_date'], date.today() + timedelta(days=14))

        # повторная выдача той же книги запрещена
        r = c.post(f'/loans/issue/{book["id"]}', follow_redirects=True)
        self.assertIn('уже у вас на руках', r.get_data(as_text=True))

        r = c.post(f'/loans/{loan["id"]}/return', follow_redirects=True)
        self.assertIn('Книга возвращена', r.get_data(as_text=True))
        self.assertEqual(self.book_state(book['id']), 2)
        self.assertEqual(query('SELECT COUNT(*) c FROM fines WHERE user_id=%s', (uid,), one=True)['c'], 0)

    def test_no_copies_left(self):
        book, _ = self.make_book(copies=1)
        c1, _ = self.register_and_login(PREFIX + '_a')
        c2, _ = self.register_and_login(PREFIX + '_b')
        c1.post(f'/loans/issue/{book["id"]}')
        r = c2.post(f'/loans/issue/{book["id"]}', follow_redirects=True)
        self.assertIn('Свободных экземпляров нет', r.get_data(as_text=True))
        self.assertIn('Встать в очередь', c2.get(f'/books/{book["id"]}').get_data(as_text=True))
        self.assertEqual(self.book_state(book['id']), 0)

    def test_limit_three_books(self):
        c, _ = self.register_and_login()
        books = [self.make_book(copies=1, title=f'{PREFIX} lim{i}')[0] for i in range(4)]
        for b in books[:3]:
            c.post(f'/loans/issue/{b["id"]}')
        r = c.post(f'/loans/issue/{books[3]["id"]}', follow_redirects=True)
        self.assertIn('Лимит', r.get_data(as_text=True))

    def test_extend_only_once(self):
        book, _ = self.make_book()
        c, uid = self.register_and_login()
        c.post(f'/loans/issue/{book["id"]}')
        loan = query('SELECT * FROM loans WHERE user_id=%s', (uid,), one=True)
        r = c.post(f'/loans/{loan["id"]}/extend', follow_redirects=True)
        self.assertIn('Срок продлён', r.get_data(as_text=True))
        r = c.post(f'/loans/{loan["id"]}/extend', follow_redirects=True)
        self.assertIn('только один раз', r.get_data(as_text=True))
        new = query('SELECT due_date FROM loans WHERE id=%s', (loan['id'],), one=True)
        self.assertEqual(new['due_date'], date.today() + timedelta(days=21))

    def test_overdue_fine_and_block(self):
        book, admin = self.make_book(copies=2)
        c, uid = self.register_and_login()
        c.post(f'/loans/issue/{book["id"]}')
        loan = query('SELECT * FROM loans WHERE user_id=%s', (uid,), one=True)
        execute('UPDATE loans SET due_date=%s WHERE id=%s',
                (date.today() - timedelta(days=3), loan['id']))

        # просрочка мешает взять новую книгу и продлить
        other, _ = self.make_book(copies=1, title=PREFIX + ' other')
        r = c.post(f'/loans/issue/{other["id"]}', follow_redirects=True)
        self.assertIn('просроченные', r.get_data(as_text=True))
        r = c.post(f'/loans/{loan["id"]}/extend', follow_redirects=True)
        self.assertIn('Срок истёк', r.get_data(as_text=True))
        self.assertIn('Просрочена', c.get('/loans/my').get_data(as_text=True))

        # возврат -> штраф 3 дня * 10 = 30
        r = c.post(f'/loans/{loan["id"]}/return', follow_redirects=True)
        self.assertIn('Начислен штраф: 30', r.get_data(as_text=True))
        fine = query('SELECT * FROM fines WHERE user_id=%s', (uid,), one=True)
        self.assertEqual((fine['days'], int(fine['amount']), fine['paid']), (3, 30, 0))

        # пока штраф не оплачен — новую книгу не выдают
        r = c.post(f'/loans/issue/{other["id"]}', follow_redirects=True)
        self.assertIn('неоплаченный штраф', r.get_data(as_text=True))

        # админ принимает оплату -> выдача снова возможна
        admin.post(f'/admin/fines/{fine["id"]}/pay')
        r = c.post(f'/loans/issue/{other["id"]}', follow_redirects=True)
        self.assertIn('Книга выдана', r.get_data(as_text=True))

    def test_cannot_delete_book_on_loan(self):
        book, admin = self.make_book()
        c, _ = self.register_and_login()
        c.post(f'/loans/issue/{book["id"]}')
        r = admin.post(f'/books/{book["id"]}/delete', follow_redirects=True)
        self.assertIn('Нельзя удалить', r.get_data(as_text=True))
        self.assertIsNotNone(query('SELECT id FROM books WHERE id=%s', (book['id'],), one=True))

    def test_other_user_cannot_return_foreign_loan(self):
        book, _ = self.make_book()
        c1, uid = self.register_and_login(PREFIX + '_a')
        c2, _ = self.register_and_login(PREFIX + '_b')
        c1.post(f'/loans/issue/{book["id"]}')
        loan = query('SELECT id FROM loans WHERE user_id=%s', (uid,), one=True)
        self.assertEqual(c2.post(f'/loans/{loan["id"]}/return').status_code, 403)


class TestReservations(AppTestCase):
    def res_status(self, uid, book_id):
        row = query('SELECT status FROM reservations WHERE user_id=%s AND book_id=%s '
                    'ORDER BY id DESC', (uid, book_id), one=True)
        return row['status'] if row else None

    def test_cannot_reserve_free_book(self):
        book, _ = self.make_book(copies=2)
        c, _ = self.register_and_login()
        r = c.post(f'/reservations/book/{book["id"]}', follow_redirects=True)
        self.assertIn('бронировать не нужно', r.get_data(as_text=True))

    def test_queue_and_automatic_handover(self):
        book, _ = self.make_book(copies=1)
        a, a_id = self.register_and_login(PREFIX + '_a')
        b, b_id = self.register_and_login(PREFIX + '_b')
        c, c_id = self.register_and_login(PREFIX + '_c')

        a.post(f'/loans/issue/{book["id"]}')               # книга у A, экземпляров 0
        r = b.post(f'/reservations/book/{book["id"]}', follow_redirects=True)
        self.assertIn('встали в очередь', r.get_data(as_text=True))
        c.post(f'/reservations/book/{book["id"]}')
        self.assertIn('Вы уже стоите', b.post(f'/reservations/book/{book["id"]}',
                                              follow_redirects=True).get_data(as_text=True))
        self.assertIn('Вы в очереди: №2', c.get(f'/books/{book["id"]}').get_data(as_text=True))

        # A возвращает -> экземпляр автоматически придерживается для B
        loan = query('SELECT id FROM loans WHERE user_id=%s', (a_id,), one=True)
        a.post(f'/loans/{loan["id"]}/return')
        self.assertEqual(self.res_status(b_id, book['id']), 'ready')
        self.assertEqual(self.res_status(c_id, book['id']), 'waiting')

        # чужие читатели не могут занять придержанный экземпляр, B — может
        r = c.post(f'/loans/issue/{book["id"]}', follow_redirects=True)
        self.assertIn('забронированы другими', r.get_data(as_text=True))
        r = b.post(f'/loans/issue/{book["id"]}', follow_redirects=True)
        self.assertIn('Книга выдана', r.get_data(as_text=True))
        self.assertEqual(self.res_status(b_id, book['id']), 'fulfilled')

    def test_cancel_passes_turn_on(self):
        book, _ = self.make_book(copies=1)
        a, a_id = self.register_and_login(PREFIX + '_a')
        b, b_id = self.register_and_login(PREFIX + '_b')
        c, c_id = self.register_and_login(PREFIX + '_c')
        a.post(f'/loans/issue/{book["id"]}')
        b.post(f'/reservations/book/{book["id"]}')
        c.post(f'/reservations/book/{book["id"]}')
        loan = query('SELECT id FROM loans WHERE user_id=%s', (a_id,), one=True)
        a.post(f'/loans/{loan["id"]}/return')               # B ready

        res = query('SELECT id FROM reservations WHERE user_id=%s', (b_id,), one=True)
        self.assertEqual(c.post(f'/reservations/{res["id"]}/cancel').status_code, 302)
        self.assertEqual(self.res_status(b_id, book['id']), 'ready')   # чужую не отменить
        b.post(f'/reservations/{res["id"]}/cancel')
        self.assertEqual(self.res_status(b_id, book['id']), 'cancelled')
        self.assertEqual(self.res_status(c_id, book['id']), 'ready')   # очередь сдвинулась

    def test_expired_hold_is_released(self):
        book, _ = self.make_book(copies=1)
        a, a_id = self.register_and_login(PREFIX + '_a')
        b, b_id = self.register_and_login(PREFIX + '_b')
        c, c_id = self.register_and_login(PREFIX + '_c')
        a.post(f'/loans/issue/{book["id"]}')
        b.post(f'/reservations/book/{book["id"]}')
        c.post(f'/reservations/book/{book["id"]}')
        loan = query('SELECT id FROM loans WHERE user_id=%s', (a_id,), one=True)
        a.post(f'/loans/{loan["id"]}/return')
        execute("UPDATE reservations SET ready_until=%s WHERE user_id=%s",
                (date.today() - timedelta(days=1), b_id))
        b.get(f'/books/{book["id"]}')                       # любое обращение пересчитывает очередь
        self.assertEqual(self.res_status(b_id, book['id']), 'expired')
        self.assertEqual(self.res_status(c_id, book['id']), 'ready')

    def test_my_loans_and_admin_pages(self):
        book, admin = self.make_book(copies=1)
        a, _ = self.register_and_login(PREFIX + '_a')
        b, _ = self.register_and_login(PREFIX + '_b')
        a.post(f'/loans/issue/{book["id"]}')
        b.post(f'/reservations/book/{book["id"]}')
        self.assertIn('Мои брони', b.get('/loans/my').get_data(as_text=True))
        self.assertIn(PREFIX, admin.get('/reservations/all').get_data(as_text=True))
        self.assertEqual(b.get('/reservations/all').status_code, 403)


class TestReviews(AppTestCase):
    def test_only_borrowers_can_review(self):
        book, _ = self.make_book(copies=2)
        c, uid = self.register_and_login()
        r = c.post(f'/reviews/book/{book["id"]}', data={'rating': 5, 'text': 'x'}, follow_redirects=True)
        self.assertIn('только на книгу, которую вы брали', r.get_data(as_text=True))

        c.post(f'/loans/issue/{book["id"]}')
        r = c.post(f'/reviews/book/{book["id"]}', data={'rating': 4, 'text': 'Отлично'}, follow_redirects=True)
        self.assertIn('Спасибо за отзыв', r.get_data(as_text=True))
        self.assertIn('Отлично', c.get(f'/books/{book["id"]}').get_data(as_text=True))

        # повторный отзыв обновляет прежний, а не дублирует
        c.post(f'/reviews/book/{book["id"]}', data={'rating': 2, 'text': 'Передумал'})
        rows = query('SELECT rating FROM reviews WHERE user_id=%s', (uid,))
        self.assertEqual([r['rating'] for r in rows], [2])

    def test_rating_validation_and_average(self):
        book, _ = self.make_book(copies=2)
        a, _ = self.register_and_login(PREFIX + '_a')
        b, _ = self.register_and_login(PREFIX + '_b')
        for c in (a, b):
            c.post(f'/loans/issue/{book["id"]}')
        r = a.post(f'/reviews/book/{book["id"]}', data={'rating': 9}, follow_redirects=True)
        self.assertIn('от 1 до 5', r.get_data(as_text=True))
        a.post(f'/reviews/book/{book["id"]}', data={'rating': 5})
        b.post(f'/reviews/book/{book["id"]}', data={'rating': 4})
        row = query('SELECT ROUND(AVG(rating), 1) AS a FROM reviews WHERE book_id=%s', (book['id'],), one=True)
        self.assertEqual(float(row['a']), 4.5)
        self.assertIn('4.5', self.client.get(f'/books/{book["id"]}').get_data(as_text=True))

    def test_delete_rights(self):
        book, admin = self.make_book(copies=2)
        a, a_id = self.register_and_login(PREFIX + '_a')
        b, _ = self.register_and_login(PREFIX + '_b')
        a.post(f'/loans/issue/{book["id"]}')
        a.post(f'/reviews/book/{book["id"]}', data={'rating': 3})
        rid = query('SELECT id FROM reviews WHERE user_id=%s', (a_id,), one=True)['id']
        self.assertEqual(b.post(f'/reviews/{rid}/delete').status_code, 403)
        self.assertEqual(admin.post(f'/reviews/{rid}/delete').status_code, 302)
        self.assertIsNone(query('SELECT id FROM reviews WHERE id=%s', (rid,), one=True))


class TestAdminAndReports(AppTestCase):
    def test_block_user_prevents_login(self):
        _, uid = self.register_and_login()
        admin = self.admin_client()
        admin.post(f'/admin/users/{uid}/toggle')
        r = self.login(self.app.test_client(), PREFIX + '_reader', 'secret1')
        self.assertIn('заблокирован', r.get_data(as_text=True))

    def test_cannot_modify_self(self):
        admin = self.admin_client()
        me = query("SELECT id FROM users WHERE username='admin'", one=True)['id']
        r = admin.post(f'/admin/users/{me}/role', follow_redirects=True)
        self.assertIn('Нельзя менять собственную', r.get_data(as_text=True))

    def test_reports_and_exports(self):
        c = self.admin_client()
        self.assertEqual(c.get('/reports/?date_from=2020-01-01&date_to=2030-01-01').status_code, 200)
        self.assertEqual(c.get('/reports/?date_from=bad').status_code, 200)
        for name in ('overdue', 'popular', 'loans', 'fines', 'reservations', 'rating'):
            x = c.get(f'/reports/{name}/export/xlsx')
            self.assertEqual(x.status_code, 200, name)
            self.assertTrue(x.data.startswith(b'PK'), name)  # xlsx = zip
            v = c.get(f'/reports/{name}/export/csv')
            self.assertEqual(v.status_code, 200, name)
            self.assertTrue(v.data.startswith(b'\xef\xbb\xbf'), name)
        self.assertEqual(c.get('/reports/nope/export/csv').status_code, 404)


if __name__ == '__main__':
    unittest.main()
