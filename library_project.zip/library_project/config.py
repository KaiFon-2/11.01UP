import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-change-me')

    # Подключение к MySQL
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = int(os.environ.get('DB_PORT', 3306))
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', 'root')
    DB_NAME = os.environ.get('DB_NAME', 'library_db')

    # Бизнес-правила библиотеки
    LOAN_DAYS = 14           # срок выдачи книги
    EXTEND_DAYS = 7          # на сколько дней можно продлить (один раз)
    MAX_ACTIVE_LOANS = 3     # максимум книг на руках у читателя
    FINE_PER_DAY = 10        # штраф за день просрочки, руб.
    RESERVE_HOLD_DAYS = 3    # сколько дней держится бронь, когда книга освободилась

    # Загрузка обложек
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'img', 'covers')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024

    BOOKS_PER_PAGE = 12
