from datetime import date, timedelta

from flask import current_app

from db import execute, query, transaction


class ReservationError(Exception):
    """Нарушено правило бронирования (текст показывается пользователю)."""


def ready_count(book_id):
    """Сколько экземпляров сейчас придержано под брони."""
    return query("SELECT COUNT(*) AS c FROM reservations WHERE book_id=%s AND status='ready'",
                 (book_id,), one=True)['c']


def refresh(book_id):
    """Автоматика очереди: снимает просроченные брони и отдаёт свободные
    экземпляры первым в очереди (статус waiting -> ready на RESERVE_HOLD_DAYS дней)."""
    today = date.today()
    execute("UPDATE reservations SET status='expired' "
            "WHERE book_id=%s AND status='ready' AND ready_until < %s", (book_id, today))

    book = query('SELECT available_copies FROM books WHERE id=%s', (book_id,), one=True)
    if not book:
        return
    free = book['available_copies'] - ready_count(book_id)
    if free <= 0:
        return

    until = today + timedelta(days=current_app.config['RESERVE_HOLD_DAYS'])
    waiting = query("SELECT id FROM reservations WHERE book_id=%s AND status='waiting' "
                    "ORDER BY created_at, id LIMIT %s", (book_id, free))
    for w in waiting:
        execute("UPDATE reservations SET status='ready', ready_until=%s WHERE id=%s",
                (until, w['id']))


@transaction
def reserve(user_id, book_id):
    book = query('SELECT id, available_copies FROM books WHERE id=%s FOR UPDATE',
                 (book_id,), one=True)
    if not book:
        raise ReservationError('Книга не найдена.')
    refresh(book_id)

    if book['available_copies'] - ready_count(book_id) > 0:
        raise ReservationError('Книга свободна — бронировать не нужно, возьмите её сразу.')
    if query('SELECT id FROM loans WHERE user_id=%s AND book_id=%s AND return_date IS NULL',
             (user_id, book_id), one=True):
        raise ReservationError('Эта книга уже у вас на руках.')
    if query("SELECT id FROM reservations WHERE user_id=%s AND book_id=%s "
             "AND status IN ('waiting', 'ready')", (user_id, book_id), one=True):
        raise ReservationError('Вы уже стоите в очереди на эту книгу.')

    return execute('INSERT INTO reservations (user_id, book_id) VALUES (%s, %s)',
                   (user_id, book_id))


@transaction
def cancel(reservation_id, user_id, is_admin=False):
    res = query('SELECT * FROM reservations WHERE id=%s FOR UPDATE', (reservation_id,), one=True)
    if not res:
        raise ReservationError('Бронь не найдена.')
    if res['user_id'] != user_id and not is_admin:
        raise ReservationError('Это чужая бронь.')
    if res['status'] not in ('waiting', 'ready'):
        raise ReservationError('Бронь уже не активна.')

    execute("UPDATE reservations SET status='cancelled' WHERE id=%s", (reservation_id,))
    refresh(res['book_id'])  # освободившееся место сразу получает следующий в очереди
