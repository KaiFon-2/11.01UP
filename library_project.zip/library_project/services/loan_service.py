from datetime import date, timedelta

from flask import current_app

from db import execute, query, transaction
from services import reservation_service
from services.fine_service import calc_fine, overdue_days


class LoanError(Exception):
    """Нарушено бизнес-правило выдачи/возврата (текст показывается пользователю)."""


@transaction
def issue_book(user_id, book_id):
    cfg = current_app.config

    book = query('SELECT id, title, available_copies FROM books WHERE id=%s FOR UPDATE',
                 (book_id,), one=True)
    if not book:
        raise LoanError('Книга не найдена.')

    # Часть экземпляров может быть придержана под брони других читателей
    reservation_service.refresh(book_id)
    book = query('SELECT available_copies FROM books WHERE id=%s', (book_id,), one=True)
    mine = query("SELECT id FROM reservations WHERE user_id=%s AND book_id=%s AND status='ready'",
                 (user_id, book_id), one=True)
    held = reservation_service.ready_count(book_id)
    free = book['available_copies'] - held + (1 if mine else 0)
    if free <= 0:
        if book['available_copies'] <= 0:
            raise LoanError('Свободных экземпляров нет — можно встать в очередь.')
        raise LoanError('Свободные экземпляры забронированы другими читателями.')

    today = date.today()
    active = query('SELECT book_id, due_date FROM loans WHERE user_id=%s AND return_date IS NULL',
                   (user_id,))
    if len(active) >= cfg['MAX_ACTIVE_LOANS']:
        raise LoanError(f'Лимит: не более {cfg["MAX_ACTIVE_LOANS"]} книг на руках.')
    if any(a['book_id'] == book_id for a in active):
        raise LoanError('Эта книга уже у вас на руках.')
    if any(a['due_date'] < today for a in active):
        raise LoanError('Сначала верните просроченные книги.')

    debt = query('SELECT COALESCE(SUM(amount), 0) AS s FROM fines WHERE user_id=%s AND paid=0',
                 (user_id,), one=True)['s']
    if debt > 0:
        raise LoanError(f'Есть неоплаченный штраф: {debt} руб.')

    due = today + timedelta(days=cfg['LOAN_DAYS'])
    loan_id = execute('INSERT INTO loans (user_id, book_id, loan_date, due_date) '
                      'VALUES (%s, %s, %s, %s)', (user_id, book_id, today, due))
    execute('UPDATE books SET available_copies = available_copies - 1 WHERE id=%s', (book_id,))
    if mine:
        execute("UPDATE reservations SET status='fulfilled' WHERE id=%s", (mine['id'],))
    return loan_id


@transaction
def return_book(loan_id):
    """Возврат книги. При просрочке штраф создаётся автоматически, а освободившийся
    экземпляр передаётся первому в очереди бронирования. Возвращает сумму штрафа."""
    loan = query('SELECT * FROM loans WHERE id=%s FOR UPDATE', (loan_id,), one=True)
    if not loan:
        raise LoanError('Выдача не найдена.')
    if loan['return_date'] is not None:
        raise LoanError('Книга уже возвращена.')

    today = date.today()
    execute('UPDATE loans SET return_date=%s WHERE id=%s', (today, loan_id))
    execute('UPDATE books SET available_copies = available_copies + 1 WHERE id=%s',
            (loan['book_id'],))
    reservation_service.refresh(loan['book_id'])

    days = overdue_days(loan['due_date'], today)
    if days > 0:
        amount = calc_fine(days)
        execute('INSERT INTO fines (loan_id, user_id, days, amount) VALUES (%s, %s, %s, %s)',
                (loan_id, loan['user_id'], days, amount))
        return amount
    return 0


@transaction
def extend_loan(loan_id, user_id):
    loan = query('SELECT * FROM loans WHERE id=%s AND user_id=%s FOR UPDATE',
                 (loan_id, user_id), one=True)
    if not loan:
        raise LoanError('Выдача не найдена.')
    if loan['return_date'] is not None:
        raise LoanError('Книга уже возвращена.')
    if loan['extended']:
        raise LoanError('Продлить можно только один раз.')
    if loan['due_date'] < date.today():
        raise LoanError('Срок истёк — продление невозможно, верните книгу.')

    new_due = loan['due_date'] + timedelta(days=current_app.config['EXTEND_DAYS'])
    execute('UPDATE loans SET due_date=%s, extended=1 WHERE id=%s', (new_due, loan_id))
    return new_due
