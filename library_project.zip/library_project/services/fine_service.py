from datetime import date
from decimal import Decimal

from flask import current_app

from db import query


def overdue_days(due_date, return_date=None):
    """Сколько дней просрочки на сегодня (или на дату возврата)."""
    end = return_date or date.today()
    return max((end - due_date).days, 0)


def calc_fine(days):
    return Decimal(days) * Decimal(str(current_app.config['FINE_PER_DAY']))


def decorate_loans(rows):
    """Добавляет к выдачам вычисляемые поля: просрочка и текущий штраф."""
    for r in rows:
        r['overdue_days'] = overdue_days(r['due_date'], r['return_date'])
        r['is_overdue'] = r['return_date'] is None and r['overdue_days'] > 0
        r['fine_now'] = calc_fine(r['overdue_days']) if r['is_overdue'] else Decimal(0)
    return rows


def unpaid_total(user_id):
    row = query('SELECT COALESCE(SUM(amount), 0) AS s FROM fines WHERE user_id=%s AND paid=0',
                (user_id,), one=True)
    return row['s']
