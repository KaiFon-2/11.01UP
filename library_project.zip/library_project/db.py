from functools import wraps

import pymysql
from flask import current_app, g


def get_db():
    """Одно соединение на запрос (хранится в g)."""
    if 'db' not in g:
        cfg = current_app.config
        g.db = pymysql.connect(
            host=cfg['DB_HOST'],
            port=cfg['DB_PORT'],
            user=cfg['DB_USER'],
            password=cfg['DB_PASSWORD'],
            database=cfg['DB_NAME'],
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
        )
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def query(sql, args=None, one=False):
    """SELECT: возвращает список словарей или один словарь (one=True)."""
    with get_db().cursor() as cur:
        cur.execute(sql, args or None)
        rows = cur.fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, args=None):
    """INSERT/UPDATE/DELETE: возвращает id последней вставленной записи."""
    with get_db().cursor() as cur:
        cur.execute(sql, args or None)
        return cur.lastrowid


def transaction(func):
    """Выполняет функцию в одной транзакции MySQL (при ошибке — откат)."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        db = get_db()
        db.begin()
        try:
            result = func(*args, **kwargs)
            db.commit()
            return result
        except Exception:
            db.rollback()
            raise
    return wrapper


def init_app(app):
    app.teardown_appcontext(close_db)
