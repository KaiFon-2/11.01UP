// Подтверждение опасных действий: <form data-confirm="Текст вопроса">
document.querySelectorAll('form[data-confirm]').forEach(function (form) {
  form.addEventListener('submit', function (e) {
    if (!confirm(form.dataset.confirm)) e.preventDefault();
  });
});

// Автоскрытие уведомлений через 6 секунд
setTimeout(function () {
  document.querySelectorAll('.alert-success, .alert-info').forEach(function (el) {
    bootstrap.Alert.getOrCreateInstance(el).close();
  });
}, 6000);
