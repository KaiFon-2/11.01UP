from datetime import date

from flask import Flask, g, render_template, session

import db
from config import Config
from routes import admin, auth, books, loans, reports, reservations, reviews


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    app.register_blueprint(auth.bp)
    app.register_blueprint(books.bp)
    app.register_blueprint(loans.bp)
    app.register_blueprint(admin.bp)
    app.register_blueprint(reports.bp)
    app.register_blueprint(reservations.bp)
    app.register_blueprint(reviews.bp)

    @app.before_request
    def load_user():
        user_id = session.get('user_id')
        g.user = None
        if user_id:
            g.user = db.query('SELECT id, username, full_name, email, role FROM users '
                              'WHERE id=%s AND is_active=1', (user_id,), one=True)
            if g.user is None:
                session.clear()

    @app.template_filter('dt')
    def format_date(value):
        return value.strftime('%d.%m.%Y') if value else '—'

    @app.context_processor
    def inject_globals():
        return {'current_user': g.get('user'), 'today': date.today()}

    @app.route('/')
    def index():
        stats = db.query('SELECT COUNT(*) AS titles, COALESCE(SUM(available_copies), 0) AS available '
                         'FROM books', one=True)
        new_books = db.query(
            'SELECT b.*, a.name AS author, g.name AS genre, '
            '(SELECT ROUND(AVG(rating), 1) FROM reviews rv WHERE rv.book_id=b.id) AS avg_rating '
            'FROM books b '
            'JOIN authors a ON a.id=b.author_id JOIN genres g ON g.id=b.genre_id '
            'ORDER BY b.created_at DESC, b.id DESC LIMIT 6')
        return render_template('index.html', stats=stats, new_books=new_books)

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template('errors/404.html'), 404

    return app


if __name__ == '__main__':
    create_app().run(debug=True)
