import os
import uuid
from math import ceil

from flask import (Blueprint, abort, current_app, flash, g, redirect,
                   render_template, request, url_for)

from db import execute, query
from services import reservation_service
from utils.decorators import admin_required

bp = Blueprint('books', __name__, url_prefix='/books')

BOOK_SELECT = ('SELECT b.*, a.name AS author, g.name AS genre, '
               '(SELECT ROUND(AVG(rating), 1) FROM reviews rv WHERE rv.book_id=b.id) AS avg_rating, '
               '(SELECT COUNT(*) FROM reviews rv WHERE rv.book_id=b.id) AS reviews_count '
               'FROM books b JOIN authors a ON a.id=b.author_id JOIN genres g ON g.id=b.genre_id ')


@bp.route('/')
def list_books():
    q = request.args.get('q', '').strip()
    genre_id = request.args.get('genre', type=int)
    only_available = request.args.get('available') == '1'
    page = max(request.args.get('page', 1, type=int), 1)
    per_page = current_app.config['BOOKS_PER_PAGE']

    where, args = [], []
    if q:
        where.append('(b.title LIKE %s OR a.name LIKE %s)')
        args += [f'%{q}%', f'%{q}%']
    if genre_id:
        where.append('b.genre_id=%s')
        args.append(genre_id)
    if only_available:
        where.append('b.available_copies > 0')
    where_sql = ('WHERE ' + ' AND '.join(where) + ' ') if where else ''

    total = query('SELECT COUNT(*) AS c FROM books b JOIN authors a ON a.id=b.author_id '
                  + where_sql, args, one=True)['c']
    books = query(BOOK_SELECT + where_sql + 'ORDER BY b.title LIMIT %s OFFSET %s',
                  args + [per_page, (page - 1) * per_page])
    genres = query('SELECT * FROM genres ORDER BY name')

    return render_template('books/list.html', books=books, genres=genres, q=q,
                           genre_id=genre_id, only_available=only_available,
                           page=page, pages=max(ceil(total / per_page), 1), total=total)


@bp.route('/<int:book_id>')
def detail(book_id):
    book = query(BOOK_SELECT + 'WHERE b.id=%s', (book_id,), one=True)
    if not book:
        abort(404)

    reservation_service.refresh(book_id)   # актуализируем очередь перед показом
    held = reservation_service.ready_count(book_id)

    user_loan = reservation = my_review = None
    can_review = False
    if g.user:
        uid = g.user['id']
        user_loan = query('SELECT * FROM loans WHERE user_id=%s AND book_id=%s '
                          'AND return_date IS NULL', (uid, book_id), one=True)
        reservation = query(
            "SELECT r.*, (SELECT COUNT(*) FROM reservations r2 WHERE r2.book_id=r.book_id "
            "AND r2.status IN ('waiting', 'ready') AND (r2.created_at < r.created_at "
            "OR (r2.created_at = r.created_at AND r2.id <= r.id))) AS position "
            "FROM reservations r WHERE r.user_id=%s AND r.book_id=%s "
            "AND r.status IN ('waiting', 'ready')", (uid, book_id), one=True)
        can_review = bool(query('SELECT id FROM loans WHERE user_id=%s AND book_id=%s LIMIT 1',
                                (uid, book_id), one=True))
        my_review = query('SELECT * FROM reviews WHERE user_id=%s AND book_id=%s',
                          (uid, book_id), one=True)

    reviews = query('SELECT rv.*, u.full_name FROM reviews rv JOIN users u ON u.id=rv.user_id '
                    'WHERE rv.book_id=%s ORDER BY rv.created_at DESC', (book_id,))
    return render_template('books/detail.html', book=book, user_loan=user_loan,
                           reservation=reservation, free=book['available_copies'] - held,
                           held=held, reviews=reviews, can_review=can_review,
                           my_review=my_review)


def _read_form():
    """Читает и проверяет форму книги. Возвращает (data, errors)."""
    f = request.form
    data = {
        'title': f.get('title', '').strip(),
        'author': f.get('author', '').strip(),
        'genre_id': f.get('genre_id', type=int),
        'year': f.get('year', type=int),
        'description': f.get('description', '').strip() or None,
        'total_copies': f.get('total_copies', type=int),
    }
    errors = []
    if not data['title']:
        errors.append('Укажите название.')
    if not data['author']:
        errors.append('Укажите автора.')
    if not data['genre_id'] or not query('SELECT id FROM genres WHERE id=%s',
                                         (data['genre_id'],), one=True):
        errors.append('Выберите жанр.')
    if data['year'] is not None and not (0 < data['year'] <= 2100):
        errors.append('Некорректный год.')
    if data['total_copies'] is None or data['total_copies'] < 1:
        errors.append('Количество экземпляров — минимум 1.')
    return data, errors


def _author_id(name):
    row = query('SELECT id FROM authors WHERE name=%s', (name,), one=True)
    return row['id'] if row else execute('INSERT INTO authors (name) VALUES (%s)', (name,))


def _save_cover(old=None):
    """Сохраняет загруженную обложку; возвращает имя файла (или старое)."""
    file = request.files.get('cover')
    if not file or not file.filename:
        return old
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if ext not in current_app.config['ALLOWED_EXTENSIONS']:
        flash('Обложка должна быть png, jpg или webp — файл пропущен.', 'warning')
        return old
    name = f'{uuid.uuid4().hex}.{ext}'
    file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], name))
    if old:
        _remove_cover(old)
    return name


def _remove_cover(name):
    try:
        os.remove(os.path.join(current_app.config['UPLOAD_FOLDER'], name))
    except OSError:
        pass


@bp.route('/add', methods=['GET', 'POST'])
@admin_required
def add():
    genres = query('SELECT * FROM genres ORDER BY name')
    if request.method == 'POST':
        data, errors = _read_form()
        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('books/form.html', book=data, genres=genres, mode='add')
        book_id = execute(
            'INSERT INTO books (title, author_id, genre_id, year, description, cover, '
            'total_copies, available_copies) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)',
            (data['title'], _author_id(data['author']), data['genre_id'], data['year'],
             data['description'], _save_cover(), data['total_copies'], data['total_copies']))
        flash('Книга добавлена.', 'success')
        return redirect(url_for('books.detail', book_id=book_id))
    return render_template('books/form.html', book={}, genres=genres, mode='add')


@bp.route('/<int:book_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit(book_id):
    book = query(BOOK_SELECT + 'WHERE b.id=%s', (book_id,), one=True)
    if not book:
        abort(404)
    genres = query('SELECT * FROM genres ORDER BY name')

    if request.method == 'POST':
        data, errors = _read_form()
        on_loan = book['total_copies'] - book['available_copies']
        if data['total_copies'] is not None and data['total_copies'] < on_loan:
            errors.append(f'Сейчас на руках {on_loan} экз. — всего не может быть меньше.')
        if errors:
            for e in errors:
                flash(e, 'danger')
            data['id'] = book_id
            data['cover'] = book['cover']
            return render_template('books/form.html', book=data, genres=genres, mode='edit')

        execute('UPDATE books SET title=%s, author_id=%s, genre_id=%s, year=%s, description=%s, '
                'cover=%s, total_copies=%s, available_copies=%s WHERE id=%s',
                (data['title'], _author_id(data['author']), data['genre_id'], data['year'],
                 data['description'], _save_cover(book['cover']), data['total_copies'],
                 data['total_copies'] - on_loan, book_id))
        reservation_service.refresh(book_id)   # новые экземпляры сразу уходят в очередь
        flash('Изменения сохранены.', 'success')
        return redirect(url_for('books.detail', book_id=book_id))
    return render_template('books/form.html', book=book, genres=genres, mode='edit')


@bp.route('/<int:book_id>/delete', methods=['POST'])
@admin_required
def delete(book_id):
    book = query('SELECT id, title, cover FROM books WHERE id=%s', (book_id,), one=True)
    if not book:
        abort(404)
    if query('SELECT id FROM loans WHERE book_id=%s AND return_date IS NULL LIMIT 1',
             (book_id,), one=True):
        flash('Нельзя удалить: книга сейчас у читателей.', 'danger')
        return redirect(url_for('books.detail', book_id=book_id))

    execute('DELETE FROM books WHERE id=%s', (book_id,))
    if book['cover']:
        _remove_cover(book['cover'])
    flash(f'Книга «{book["title"]}» удалена.', 'success')
    return redirect(url_for('books.list_books'))
