import re

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from db import execute, query

bp = Blueprint('auth', __name__)

EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def _safe_next(target):
    """Редирект только на внутренние адреса."""
    if target and target.startswith('/') and not target.startswith('//'):
        return target
    return url_for('index')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = query('SELECT * FROM users WHERE username=%s', (username,), one=True)

        if not user or not check_password_hash(user['password_hash'], password):
            flash('Неверный логин или пароль.', 'danger')
        elif not user['is_active']:
            flash('Аккаунт заблокирован администратором.', 'danger')
        else:
            session.clear()
            session['user_id'] = user['id']
            flash(f'Добро пожаловать, {user["full_name"]}!', 'success')
            return redirect(_safe_next(request.args.get('next')))
    return render_template('auth/login.html')


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        password2 = request.form.get('password2', '')

        errors = []
        if len(username) < 3:
            errors.append('Логин — минимум 3 символа.')
        if not full_name:
            errors.append('Укажите ФИО.')
        if not EMAIL_RE.match(email):
            errors.append('Некорректный email.')
        if len(password) < 6:
            errors.append('Пароль — минимум 6 символов.')
        if password != password2:
            errors.append('Пароли не совпадают.')
        if not errors and query('SELECT id FROM users WHERE username=%s OR email=%s',
                                (username, email), one=True):
            errors.append('Пользователь с таким логином или email уже существует.')

        if errors:
            for e in errors:
                flash(e, 'danger')
        else:
            execute('INSERT INTO users (username, email, full_name, password_hash) '
                    'VALUES (%s, %s, %s, %s)',
                    (username, email, full_name, generate_password_hash(password)))
            flash('Регистрация успешна. Теперь войдите.', 'success')
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы.', 'info')
    return redirect(url_for('index'))
