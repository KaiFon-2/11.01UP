import csv
import io
from datetime import date, timedelta

from flask import Blueprint, Response, abort, render_template, request, send_file
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from db import query
from services.fine_service import calc_fine, overdue_days
from utils.decorators import admin_required

bp = Blueprint('reports', __name__, url_prefix='/reports')


def _fmt(d):
    return d.strftime('%d.%m.%Y') if d else ''


# Каждый отчёт возвращает (заголовок, названия колонок, строки-кортежи)

def report_overdue(d_from, d_to):
    rows = query('SELECT u.full_name, u.email, b.title, l.loan_date, l.due_date FROM loans l '
                 'JOIN users u ON u.id=l.user_id JOIN books b ON b.id=l.book_id '
                 'WHERE l.return_date IS NULL AND l.due_date < CURDATE() ORDER BY l.due_date')
    data = []
    for r in rows:
        days = overdue_days(r['due_date'])
        data.append((r['full_name'], r['email'], r['title'], _fmt(r['loan_date']),
                     _fmt(r['due_date']), days, float(calc_fine(days))))
    return ('Должники (просроченные книги)',
            ['Читатель', 'Email', 'Книга', 'Выдана', 'Срок возврата', 'Дней просрочки',
             'Штраф, руб.'], data)


def report_popular(d_from, d_to):
    rows = query('SELECT b.title, a.name AS author, g.name AS genre, COUNT(l.id) AS cnt '
                 'FROM loans l JOIN books b ON b.id=l.book_id JOIN authors a ON a.id=b.author_id '
                 'JOIN genres g ON g.id=b.genre_id WHERE l.loan_date BETWEEN %s AND %s '
                 'GROUP BY b.id ORDER BY cnt DESC, b.title LIMIT 20', (d_from, d_to))
    return ('Популярные книги за период', ['Книга', 'Автор', 'Жанр', 'Выдач'],
            [(r['title'], r['author'], r['genre'], r['cnt']) for r in rows])


def report_loans(d_from, d_to):
    rows = query('SELECT u.full_name, b.title, l.loan_date, l.due_date, l.return_date FROM loans l '
                 'JOIN users u ON u.id=l.user_id JOIN books b ON b.id=l.book_id '
                 'WHERE l.loan_date BETWEEN %s AND %s ORDER BY l.loan_date DESC, l.id DESC',
                 (d_from, d_to))
    return ('Выдачи за период', ['Читатель', 'Книга', 'Выдана', 'Срок', 'Возвращена'],
            [(r['full_name'], r['title'], _fmt(r['loan_date']), _fmt(r['due_date']),
              _fmt(r['return_date']) or 'на руках') for r in rows])


def report_fines(d_from, d_to):
    rows = query('SELECT u.full_name, b.title, f.days, f.amount, f.paid, f.created_at FROM fines f '
                 'JOIN users u ON u.id=f.user_id JOIN loans l ON l.id=f.loan_id '
                 'JOIN books b ON b.id=l.book_id WHERE DATE(f.created_at) BETWEEN %s AND %s '
                 'ORDER BY f.created_at DESC', (d_from, d_to))
    return ('Штрафы за период', ['Читатель', 'Книга', 'Дней', 'Сумма, руб.', 'Статус', 'Начислен'],
            [(r['full_name'], r['title'], r['days'], float(r['amount']),
              'оплачен' if r['paid'] else 'не оплачен', _fmt(r['created_at'])) for r in rows])


def report_rating(d_from, d_to):
    rows = query('SELECT b.title, a.name AS author, ROUND(AVG(rv.rating), 2) AS avg_rating, '
                 'COUNT(rv.id) AS cnt FROM reviews rv JOIN books b ON b.id=rv.book_id '
                 'JOIN authors a ON a.id=b.author_id WHERE DATE(rv.created_at) BETWEEN %s AND %s '
                 'GROUP BY b.id ORDER BY avg_rating DESC, cnt DESC LIMIT 20', (d_from, d_to))
    return ('Рейтинг книг по отзывам за период', ['Книга', 'Автор', 'Средняя оценка', 'Отзывов'],
            [(r['title'], r['author'], float(r['avg_rating']), r['cnt']) for r in rows])


def report_reservations(d_from, d_to):
    rows = query('SELECT b.title, u.full_name, r.status, r.created_at FROM reservations r '
                 'JOIN books b ON b.id=r.book_id JOIN users u ON u.id=r.user_id '
                 'WHERE DATE(r.created_at) BETWEEN %s AND %s ORDER BY r.created_at DESC',
                 (d_from, d_to))
    names = {'waiting': 'в очереди', 'ready': 'ждёт выдачи', 'fulfilled': 'выдана',
             'cancelled': 'отменена', 'expired': 'истекла'}
    return ('Бронирования за период', ['Книга', 'Читатель', 'Статус', 'Создана'],
            [(r['title'], r['full_name'], names[r['status']], _fmt(r['created_at'])) for r in rows])


REPORTS = {
    'overdue': report_overdue,
    'popular': report_popular,
    'loans': report_loans,
    'fines': report_fines,
    'reservations': report_reservations,
    'rating': report_rating,
}


def _period():
    def parse(name, default):
        try:
            return date.fromisoformat(request.args.get(name, ''))
        except ValueError:
            return default
    today = date.today()
    d_from, d_to = parse('date_from', today - timedelta(days=30)), parse('date_to', today)
    return (d_to, d_from) if d_from > d_to else (d_from, d_to)


@bp.route('/')
@admin_required
def index():
    d_from, d_to = _period()
    reports = []
    for key, func in REPORTS.items():
        title, headers, rows = func(d_from, d_to)
        reports.append({'key': key, 'title': title, 'headers': headers, 'rows': rows})
    return render_template('reports/index.html', reports=reports, date_from=d_from, date_to=d_to)


@bp.route('/<name>/export/<fmt>')
@admin_required
def export(name, fmt):
    if name not in REPORTS or fmt not in ('csv', 'xlsx'):
        abort(404)
    d_from, d_to = _period()
    title, headers, rows = REPORTS[name](d_from, d_to)
    filename = f'report_{name}_{date.today():%Y%m%d}.{fmt}'

    if fmt == 'csv':
        buf = io.StringIO()
        writer = csv.writer(buf, delimiter=';')
        writer.writerow(headers)
        writer.writerows(rows)
        # utf-8-sig, чтобы Excel правильно открыл кириллицу
        return Response(buf.getvalue().encode('utf-8-sig'), mimetype='text/csv',
                        headers={'Content-Disposition': f'attachment; filename={filename}'})

    wb = Workbook()
    ws = wb.active
    ws.title = 'Отчёт'
    ws.append([title])
    ws['A1'].font = Font(bold=True, size=14)
    ws.append([])
    ws.append(headers)
    for cell in ws[3]:
        cell.font = Font(bold=True)
    for row in rows:
        ws.append(list(row))
    for i, col in enumerate(ws.columns, 1):
        width = max((len(str(c.value)) for c in col if c.value is not None), default=10)
        ws.column_dimensions[get_column_letter(i)].width = min(width + 2, 50)

    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return send_file(out, as_attachment=True, download_name=filename,
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
