from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from db import execute, query
from services.fine_service import decorate_loans
from utils.decorators import admin_required

bp = Blueprint('admin', __name__, url_prefix='/admin')


@bp.route('/')
@admin_required
def dashboard():
    stats = {
        'titles': query('SELECT COUNT(*) AS c FROM books', one=True)['c'],
        'copies': query('SELECT COALESCE(SUM(total_copies), 0) AS c FROM books', one=True)['c'],
        'available': query('SELECT COALESCE(SUM(available_copies), 0) AS c FROM books', one=True)['c'],
        'users': query("SELECT COUNT(*) AS c FROM users WHERE role='user'", one=True)['c'],
        'active_loans': query('SELECT COUNT(*) AS c FROM loans WHERE return_date IS NULL',
                              one=True)['c'],
        'overdue': query('SELECT COUNT(*) AS c FROM loans WHERE return_date IS NULL '
                         'AND due_date < CURDATE()', one=True)['c'],
        'unpaid': query('SELECT COALESCE(SUM(amount), 0) AS c FROM fines WHERE paid=0',
                        one=True)['c'],
    }
    select = ('SELECT l.*, b.title, u.full_name AS reader FROM loans l '
              'JOIN books b ON b.id=l.book_id JOIN users u ON u.id=l.user_id ')
    recent = query(select + 'ORDER BY l.id DESC LIMIT 5')
    overdue = decorate_loans(query(select + 'WHERE l.return_date IS NULL AND l.due_date < CURDATE() '
                                   'ORDER BY l.due_date LIMIT 5'))
    return render_template('admin/dashboard.html', stats=stats, recent=recent, overdue=overdue)


@bp.route('/users')
@admin_required
def users():
    q = request.args.get('q', '').strip()
    sql = ('SELECT u.*, (SELECT COUNT(*) FROM loans l WHERE l.user_id=u.id AND l.return_date IS NULL) '
           'AS active_loans, (SELECT COALESCE(SUM(amount), 0) FROM fines f WHERE f.user_id=u.id '
           'AND f.paid=0) AS debt FROM users u ')
    args = []
    if q:
        sql += 'WHERE u.username LIKE %s OR u.full_name LIKE %s OR u.email LIKE %s '
        args = [f'%{q}%'] * 3
    return render_template('admin/users.html', users=query(sql + 'ORDER BY u.id', args), q=q)


def _target_user(user_id):
    user = query('SELECT * FROM users WHERE id=%s', (user_id,), one=True)
    if not user:
        abort(404)
    if user['id'] == g.user['id']:
        flash('Нельзя менять собственную учётную запись.', 'danger')
        return None
    return user


@bp.route('/users/<int:user_id>/toggle', methods=['POST'])
@admin_required
def toggle_user(user_id):
    user = _target_user(user_id)
    if user:
        execute('UPDATE users SET is_active=%s WHERE id=%s', (0 if user['is_active'] else 1, user_id))
        flash('Статус пользователя изменён.', 'success')
    return redirect(url_for('admin.users'))


@bp.route('/users/<int:user_id>/role', methods=['POST'])
@admin_required
def change_role(user_id):
    user = _target_user(user_id)
    if user:
        execute('UPDATE users SET role=%s WHERE id=%s',
                ('user' if user['role'] == 'admin' else 'admin', user_id))
        flash('Роль изменена.', 'success')
    return redirect(url_for('admin.users'))


@bp.route('/fines')
@admin_required
def fines():
    rows = query('SELECT f.*, u.full_name AS reader, u.username, b.title FROM fines f '
                 'JOIN users u ON u.id=f.user_id JOIN loans l ON l.id=f.loan_id '
                 'JOIN books b ON b.id=l.book_id ORDER BY f.paid, f.created_at DESC')
    return render_template('admin/fines.html', fines=rows)


@bp.route('/fines/<int:fine_id>/pay', methods=['POST'])
@admin_required
def pay_fine(fine_id):
    execute('UPDATE fines SET paid=1 WHERE id=%s', (fine_id,))
    flash('Штраф отмечен как оплаченный.', 'success')
    return redirect(url_for('admin.fines'))
