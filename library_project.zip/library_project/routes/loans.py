from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from db import query
from services import loan_service, reservation_service
from services.fine_service import decorate_loans
from services.loan_service import LoanError
from utils.decorators import admin_required, login_required

bp = Blueprint('loans', __name__, url_prefix='/loans')

LOAN_SELECT = ('SELECT l.*, b.title, a.name AS author, u.full_name AS reader, u.username, '
               'f.amount AS fine_amount, f.paid AS fine_paid '
               'FROM loans l JOIN books b ON b.id=l.book_id JOIN authors a ON a.id=b.author_id '
               'JOIN users u ON u.id=l.user_id LEFT JOIN fines f ON f.loan_id=l.id ')


def _back(default):
    return redirect(request.referrer or default)


@bp.route('/issue/<int:book_id>', methods=['POST'])
@login_required
def issue(book_id):
    try:
        loan_service.issue_book(g.user['id'], book_id)
        flash('Книга выдана. Приятного чтения!', 'success')
        return redirect(url_for('loans.my_loans'))
    except LoanError as e:
        flash(str(e), 'danger')
        return redirect(url_for('books.detail', book_id=book_id))


@bp.route('/my')
@login_required
def my_loans():
    rows = query(LOAN_SELECT + 'WHERE l.user_id=%s '
                 'ORDER BY l.return_date IS NOT NULL, l.due_date', (g.user['id'],))
    decorate_loans(rows)
    debt = sum(r['fine_amount'] for r in rows if r['fine_amount'] and not r['fine_paid'])

    for book_id in {r['book_id'] for r in query(
            "SELECT book_id FROM reservations WHERE user_id=%s AND status IN ('waiting', 'ready')",
            (g.user['id'],))}:
        reservation_service.refresh(book_id)
    reservations = query(
        "SELECT r.*, b.title, a.name AS author, (SELECT COUNT(*) FROM reservations r2 "
        "WHERE r2.book_id=r.book_id AND r2.status IN ('waiting', 'ready') AND (r2.created_at < r.created_at "
        "OR (r2.created_at = r.created_at AND r2.id <= r.id))) AS position "
        "FROM reservations r JOIN books b ON b.id=r.book_id JOIN authors a ON a.id=b.author_id "
        "WHERE r.user_id=%s AND r.status IN ('waiting', 'ready') ORDER BY r.created_at",
        (g.user['id'],))
    return render_template('loans/my_loans.html', reservations=reservations,
                           active=[r for r in rows if r['return_date'] is None],
                           history=[r for r in rows if r['return_date'] is not None],
                           debt=debt)


@bp.route('/<int:loan_id>/return', methods=['POST'])
@login_required
def return_loan(loan_id):
    loan = query('SELECT user_id FROM loans WHERE id=%s', (loan_id,), one=True)
    if not loan:
        abort(404)
    if loan['user_id'] != g.user['id'] and g.user['role'] != 'admin':
        abort(403)
    try:
        fine = loan_service.return_book(loan_id)
        if fine:
            flash(f'Книга возвращена с просрочкой. Начислен штраф: {fine} руб.', 'warning')
        else:
            flash('Книга возвращена.', 'success')
    except LoanError as e:
        flash(str(e), 'danger')
    return _back(url_for('loans.my_loans'))


@bp.route('/<int:loan_id>/extend', methods=['POST'])
@login_required
def extend(loan_id):
    try:
        new_due = loan_service.extend_loan(loan_id, g.user['id'])
        flash(f'Срок продлён до {new_due:%d.%m.%Y}.', 'success')
    except LoanError as e:
        flash(str(e), 'danger')
    return redirect(url_for('loans.my_loans'))


@bp.route('/all')
@admin_required
def all_loans():
    status = request.args.get('status', 'active')
    q = request.args.get('q', '').strip()

    where, args = [], []
    if status == 'active':
        where.append('l.return_date IS NULL')
    elif status == 'overdue':
        where.append('l.return_date IS NULL AND l.due_date < CURDATE()')
    elif status == 'returned':
        where.append('l.return_date IS NOT NULL')
    if q:
        where.append('(b.title LIKE %s OR u.full_name LIKE %s OR u.username LIKE %s)')
        args += [f'%{q}%'] * 3
    where_sql = ('WHERE ' + ' AND '.join(where) + ' ') if where else ''

    rows = query(LOAN_SELECT + where_sql + 'ORDER BY l.loan_date DESC, l.id DESC LIMIT 300', args)
    return render_template('loans/all_loans.html', loans=decorate_loans(rows),
                           status=status, q=q)
