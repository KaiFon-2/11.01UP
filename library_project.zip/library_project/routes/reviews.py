from flask import Blueprint, abort, flash, g, redirect, request, url_for

from db import execute, query
from utils.decorators import login_required

bp = Blueprint('reviews', __name__, url_prefix='/reviews')


@bp.route('/book/<int:book_id>', methods=['POST'])
@login_required
def save(book_id):
    if not query('SELECT id FROM books WHERE id=%s', (book_id,), one=True):
        abort(404)
    rating = request.form.get('rating', type=int)
    text = request.form.get('text', '').strip()[:1000] or None

    if rating not in (1, 2, 3, 4, 5):
        flash('Поставьте оценку от 1 до 5.', 'danger')
    elif not query('SELECT id FROM loans WHERE user_id=%s AND book_id=%s LIMIT 1',
                   (g.user['id'], book_id), one=True):
        flash('Оставить отзыв можно только на книгу, которую вы брали.', 'danger')
    else:
        # один отзыв на книгу от читателя: повторная отправка обновляет прежний
        execute('INSERT INTO reviews (user_id, book_id, rating, text) VALUES (%s, %s, %s, %s) '
                'ON DUPLICATE KEY UPDATE rating=VALUES(rating), text=VALUES(text), created_at=NOW()',
                (g.user['id'], book_id, rating, text))
        flash('Спасибо за отзыв!', 'success')
    return redirect(url_for('books.detail', book_id=book_id) + '#reviews')


@bp.route('/<int:review_id>/delete', methods=['POST'])
@login_required
def delete(review_id):
    review = query('SELECT * FROM reviews WHERE id=%s', (review_id,), one=True)
    if not review:
        abort(404)
    if review['user_id'] != g.user['id'] and g.user['role'] != 'admin':
        abort(403)
    execute('DELETE FROM reviews WHERE id=%s', (review_id,))
    flash('Отзыв удалён.', 'success')
    return redirect(url_for('books.detail', book_id=review['book_id']) + '#reviews')
