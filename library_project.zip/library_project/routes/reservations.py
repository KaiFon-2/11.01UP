from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from db import query
from services import reservation_service
from services.reservation_service import ReservationError
from utils.decorators import admin_required, login_required

bp = Blueprint('reservations', __name__, url_prefix='/reservations')


@bp.route('/book/<int:book_id>', methods=['POST'])
@login_required
def reserve(book_id):
    try:
        reservation_service.reserve(g.user['id'], book_id)
        flash('Вы встали в очередь. Когда книга освободится, бронь будет придержана для вас.', 'success')
    except ReservationError as e:
        flash(str(e), 'danger')
    return redirect(url_for('books.detail', book_id=book_id))


@bp.route('/<int:reservation_id>/cancel', methods=['POST'])
@login_required
def cancel(reservation_id):
    try:
        reservation_service.cancel(reservation_id, g.user['id'], g.user['role'] == 'admin')
        flash('Бронь отменена.', 'success')
    except ReservationError as e:
        flash(str(e), 'danger')
    return redirect(request.referrer or url_for('loans.my_loans'))


@bp.route('/all')
@admin_required
def all_reservations():
    show = request.args.get('show', 'active')
    where = "WHERE r.status IN ('waiting', 'ready') " if show == 'active' else ''
    rows = query('SELECT r.*, u.full_name AS reader, u.username, b.title FROM reservations r '
                 'JOIN users u ON u.id=r.user_id JOIN books b ON b.id=r.book_id '
                 + where + 'ORDER BY r.created_at DESC, r.id DESC LIMIT 300')
    return render_template('reservations/all.html', reservations=rows, show=show)
